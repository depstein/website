There are 7 files in the supplemental materials, besides this one:

01-Captions.srt : captions file for the video figure.
02-yarn_instructions.pdf : the reference guide participants were given for how to use Yarn.
03-description_prompts.txt : the 13 description prompts generated for Yarn.
04-weekly_survey.pdf : the short survey participants completed each week.
05-final_survey.pdf : the final survey participants completed at the end of the study.
06-interview_questions.pdf : the guiding questions for the semi-structured introductory and final interview.
07-video.mp4 : the video figure.