Supplementary documents for:  Unpacking Intention and Behavior: Explaining Contact Tracing App Adoption and Hesitancy in the United States

Contents:

Accessible table versions of Figures.pdf - Tables versions of  figures that were too complex to summarize in the textual figure descriptions.

Figure_descriptions - Textual descriptions of figures for accessibilityQuestionnaire.pdf - The survey given to respondentsSupplementary Tables.pdf - Additional analysis tables not included in the main document.