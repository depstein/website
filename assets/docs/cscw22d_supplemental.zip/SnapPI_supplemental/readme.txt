There are three files in our supplementary materials. 
- Audience survey questionnaire
- Interview protocol 
- Participant manual of SnapPI which we provided to the study participants during the onboarding session

All files are PDFs and can be opened with a standard PDF reader (e.g. Adobe PDF, Preview).