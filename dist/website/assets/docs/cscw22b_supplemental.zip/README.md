{\rtf1\ansi\ansicpg936\cocoartf1561\cocoasubrtf610
{\fonttbl\f0\fswiss\fcharset0 ArialMT;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\sl340\partightenfactor0

\f0\fs29\fsmilli14667 \cf2 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 A single pdf with the survey protocol and questions participants answered, anonymized. Please refer to our prior study's (https://doi.org/10.1145/3411764.3445669) supplemental material for the survey's English version. }